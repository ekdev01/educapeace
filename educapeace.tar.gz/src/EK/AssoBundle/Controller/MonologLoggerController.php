<?php
/**
 * Created by PhpStorm.
 * User: ekdevcenter
 * Date: 16/02/2018
 * Time: 19:12
 */
namespace EK\AssoBundle\Controller;

interface MonologLoggerController
{
}