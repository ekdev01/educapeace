<?php
/**
 * Created by PhpStorm.
 * User: ekdevcenter
 * Date: 23/02/2018
 * Time: 02:19
 */

namespace EK\AssoBundle\Controller;


class SecurityController
{
	
}