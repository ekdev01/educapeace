<?php

namespace EK\AssoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AssoBundle extends Bundle
{
}
